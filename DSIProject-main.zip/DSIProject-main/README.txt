UNIVERSIDAD NACIONAL DE INGENIERIA
FACULTAD DE CIENCIAS Y SISTEMAS
INGENIERIA DE SISTEMAS

Proyecto de Diseño de Sistemas de Internet
CRUD de Ofertas de trabajo en Laravel

Integrantes:
    Elliott Noé Alvarez Parrales        2018-1074U
    Jarov Bayardo Davila Larios         2018-0948U
    Yanil Josué Morales Zeledón         2018-0983U
    Marco Antonio Talavera Gutiérrez    2018-0953U
