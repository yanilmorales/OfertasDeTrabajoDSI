function toogleModal(id){
    let modal = document.getElementById(id);
    modal.classList.toggle('hidden');
}

